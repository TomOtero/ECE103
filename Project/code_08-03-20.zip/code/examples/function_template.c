#include "sst_functions.h"
#include "function_template.h" // name the source file the same
							   // as the header with the declarations

void func(GameVariables *gameVars) //This is what I mean by 
								   //passing a pointer of type GameVariables
{
	//This is how you access variables in the struct 
	//gameVars->someElementOfgameVars;
	//
	// example: printf("%d",gameVars->stardateCurr);

}
