//Don't know this for sure, but I generally think
//the header filename must match the .c source filename

#ifndef HEADER_NAME_CAN_BE_ANYTHING //	These must match and be unique 
#define HEADER_NAME_CAN_BE_ANYTHING //	My possibly incorrect understanding is 
									//	this works similar to the concept of namespace.

	void func(GameVariables *gameVars);

		
#endif